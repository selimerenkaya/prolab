public class Person {
}

public class Passenger {
}

// Programlaba Laboratuvarı 2. Proje -- Rezervasyon Sistemi
//
// --- Projeyi Geliştirenler ---
// 230201127 Selim Eren Kaya
// 200201042 Fedai Engin Can Yılmaz

// Kullanılan Kütüphaneler
import javax.swing.*;
import java.awt.*;
import java.lang.*;

// Giriş Ekranının arayüzü
class Arayuz extends JFrame {

    // Giriş Ekranı oluşturulduğunda çalışacak kod
    public Arayuz(){
        // Ana Menünün Arayüzünün oluşturulması
        setTitle("Giriş Ekranı");
        setSize(800, 600);


        // Panel ve Butonların oluşturulması
        // Panel
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.white);


        // Butonlar
        // 1- Admin Giriş Butonu
        JButton admin_giris_butonu = new JButton("Admin Girişi");
        admin_giris_butonu.setBounds(20, 20, 150, 50);
        admin_giris_butonu.setBackground(new Color(120, 130, 255));
        // Butona tıklanınca çalışacak kısım
        admin_giris_butonu.addActionListener(e -> {
            dispose(); // Butona tıklanınca Giriş Ekranını kapatan komut
            new Admin.Admin_Giris_Arayuz(); // Admin Giriş Panelinin gözükmesini sağlayan komut
        });
        panel.add(admin_giris_butonu); // Panele eklenmesi


        // 2- Firma Giriş Butonu
        JButton firma_giris_butonu = new JButton("Firma Girişi");
        firma_giris_butonu.setBounds(190, 20, 150, 50);
        firma_giris_butonu.setBackground((Color.PINK));
        // Butona tıklanınca çalışacak kısım
        firma_giris_butonu.addActionListener(e -> {
            dispose(); // Butona tıklanınca Giriş Ekranını kapatan komut
            new Company.Firma_Giris_Arayuz(); // Firma Panelinin gözükmesini sağlayan komut
        });
        panel.add(firma_giris_butonu); // Panele eklenmesi


        // 3- Bilet Ara Butonu
        JButton bilet_ara_butonu = new JButton("Bilet Ara");
        bilet_ara_butonu.setBounds(360, 20, 150, 50);
        bilet_ara_butonu.setBackground(Color.YELLOW);
        // Butona tıklanınca çalışacak kısım
        bilet_ara_butonu.addActionListener(e -> {
            dispose(); // Butona tıklanınca Giriş Ekranını kapatan komut
            new Customer.Kullanici_Arayuz(); // Kullanıcı Panelinin gözükmesini sağlayan komut
        });
        panel.add(bilet_ara_butonu); // Panele eklenmesi


        this.getContentPane().add(panel); // Oluşturulan içeriklerin panele ekleyen kısım


        setVisible(true); // Arayüzü görünür kılan metot
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Arayüzden çıkış yapmayı sağlayan metot

    }
}

public class Main {
    public static void main(String[] args) {

        // Giriş Ekranının main içinde çağrılması
        new Transport().HazirBilgileriOlustur();
        Arayuz giris_ekrani = new Arayuz();




    }
}

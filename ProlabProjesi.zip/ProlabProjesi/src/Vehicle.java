// Araçları temsil eden Class
// Abstract bir class
// 3 Türe ayrılır
// 1- Bus
// 2- Train
// 3- Airplane
abstract class Vehicle {

}

// Otobüs Classı
class Bus extends Vehicle {

}

// Tren Classı
class Train extends Vehicle {

}

// Uçak Classı
class Airplane extends Vehicle {

}